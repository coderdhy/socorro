// Copyright (c) 2014 Google Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifdef _M_FP_PRECISE
#error
#endif

#ifndef _M_FP_STRICT
#error
#endif

#ifdef _M_FP_FAST
#error
#endif

int main() {
  return 0;
}
