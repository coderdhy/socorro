/* Copyright (c) 2011 Google Inc. All rights reserved.
 * Use of this source code is governed by a BSD-style license that can be
 * found in the LICENSE file. */

// The precompiled header does not have to be the first one in the file.

#include <windows.h>
#include <stdio.h>
